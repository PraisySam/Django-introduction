//Pure CSS Bubble Switch

//Inspired by: https://dribbble.com/shots/4229342-Light-Bulb-Switch 

// Making time ~ 3 hours